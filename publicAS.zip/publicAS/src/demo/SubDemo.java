package demo;

import publicAS.WithinClass;

public class SubDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WithinClass s=new WithinClass();
		s.setDetails(577,"naveen",77.77);
		   s.getDetails();
		   System.out.println("Outside Package \nsid: "+s.sid);
	}

}
