package demo;

import publicAS.WithinClass;
public class OutsideSubClass extends WithinClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OutsideSubClass s=new OutsideSubClass();
		s.setDetails(577,"harsha",77.77);
		   s.getDetails();
		   System.out.println("Outside Package in subClass \nsid: "+s.sid);
	}

}
