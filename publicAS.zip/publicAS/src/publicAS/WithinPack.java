package publicAS;

public class WithinPack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WithinClass s=new WithinClass();
		s.setDetails(577,"hemanth",77.77);
		   s.getDetails();
		   System.out.println("within Package \nsid: "+s.sid);
	}

}
