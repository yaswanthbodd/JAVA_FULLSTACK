package publicAS;

public class WithinClass {
	public int sid;
	public String sname;
	public double smarks;
	
	public void setDetails(int id,String name,double marks){
		sid=id;
		sname=name;
		smarks=marks;
	}
	public void getDetails(){
		System.out.println("Student Id: "+sid+"\nStudent name: "+sname+"\nStudent marks: "+smarks);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WithinClass s=new WithinClass();
		s.setDetails(577,"yaswanth",77.77);
		   s.getDetails();
		   System.out.println("within class \nsid: "+s.sid);
	}

}
