package outsidepack;
//Outside the package by subclass

import defaultAS.StudentDefault;

public class Outside1 extends StudentDefault {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDefault s=new StudentDefault();
		s.setDetails(578,"pawan",77.77);
		s.getDetails();

	}

}
