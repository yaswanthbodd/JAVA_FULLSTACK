package defaultAS;

public class StudentDefault2 {

	public static void main(String[] args) {
		StudentDefault s=new StudentDefault();
		s.setDetails(578,"pawan",77.77);
		s.getDetails();

	}

}
