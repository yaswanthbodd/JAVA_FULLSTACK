package defaultAS;

//Default Access Specifier

public class StudentDefault {
	
	int sid;
	String sname;
	double smarks;
	
	void setDetails(int id,String name,double marks){
		sid=id;
		sname=name;
		smarks=marks;
	}
	void getDetails(){
		System.out.println("Student Id: "+sid+"\nStudent name: "+sname+"\nStudent marks: "+smarks);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDefault s=new StudentDefault();
		s.setDetails(577,"yaswanth",77.77);
		   s.getDetails();
	}

}
