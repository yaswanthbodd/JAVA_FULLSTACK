import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class MyServlet extends HttpServlet{
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{

		res.setContentType("text/html");
		PrintWriter out=res.getWriter();

		String un=req.getParameter("uname");
		String pw=req.getParameter("pwd");
		if(un.equals("cse") && pw.equals("cse123")){
			out.print("valid User");
		}else{
			out.print("Invalid User");
		}
	}
	

}