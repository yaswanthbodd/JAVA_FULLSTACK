
public class ActualClass {
	static int findMax(int a[]) {
		int max=a[0];
		for(int i=1;i<a.length;i++) {
			if(a[i]>=max) {
				max=a[i];
			}
		}
		return max;
	}
	
	static int lastDigit(int n) {
		return Math.abs(n%10);
	}
}
