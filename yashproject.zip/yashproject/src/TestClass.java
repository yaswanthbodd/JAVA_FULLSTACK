import org.junit.*;
public class TestClass {
	@Test
	public void test1() {
		int a[]= {1,2,3,4,5};
		Assert.assertEquals(5,ActualClass.findMax(a));
	}
	
	@Test
	public void test2() {
		int a[]= {-5,-1,-10,-6,-4};
		Assert.assertEquals(-1,ActualClass.findMax(a));
	}
	
	@Test
	public void test3() {
		int a[]= {-300,-20,1,60,10};
		Assert.assertEquals(60,ActualClass.findMax(a));
	}
	
	@Test
	public void test4() {
		Assert.assertEquals(5,ActualClass.lastDigit(675));
	}
	
	@Test
	public void test5() {
		Assert.assertEquals(7,ActualClass.lastDigit(-577));
	}
	
}
