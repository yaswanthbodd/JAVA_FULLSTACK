/**
 * 
 */
/**
 * 
 */
module protectedAS {
}