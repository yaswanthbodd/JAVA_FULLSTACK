package protectedAS;

public class WithinPackage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WithinClass s=new WithinClass();
		s.setDetails(568,"hemanth",77.77);
		   s.getDetails();
		   System.out.println("Protected Access Specifier within package \nsid: "+s.sid);
	}

}
