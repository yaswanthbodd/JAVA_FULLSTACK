package Demo;

import protectedAS.WithinClass;

public class SubDemo extends WithinClass{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubDemo s= new SubDemo();
		s.setDetails(568,"hemanth",77.77);
		   s.getDetails();
		   System.out.println("Protected Access Specifier within package \nsid: "+s.sid);
	}

}
