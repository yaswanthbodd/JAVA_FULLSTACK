package Demo;

import protectedAS.WithinClass;

public class OutsidePack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WithinClass s=new WithinClass();
		s.setDetails(577,"yaswanth",77.77);
		   s.getDetails();
		   System.out.println("Protected Access Specifier within class \nsid: "+s.sid);
	}

}
